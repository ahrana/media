chrome.runtime.onInstalled.addListener(() => {
  console.log('Daily Notes extension installed.');
});
